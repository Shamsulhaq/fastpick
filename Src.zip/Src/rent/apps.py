from django.apps import AppConfig


class RentConfig(AppConfig):
    name = 'rent'
