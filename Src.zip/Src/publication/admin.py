from django.contrib import admin
from publication.models import Publication

# Register your models here.

admin.site.register(Publication)