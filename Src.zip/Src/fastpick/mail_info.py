EMAIL_USE_TLS = True
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_HOST_USER = 'fastpick.xyz@gmail.com'
EMAIL_HOST_PASSWORD = '742436sam'
EMAIL_PORT = 587




# EMAIL_HOST = 'smtp.sendgrid.net'
# EMAIL_HOST_USER = 'shamsul65'
# EMAIL_HOST_PASSWORD = '742436sam'
# EMAIL_PORT = 587
# EMAIL_USE_TLS = True


# EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
# EMAIL_HOST = 'smtp.gmail.com'
# EMAIL_USE_TLS = True
# EMAIL_PORT = 587
# DEFAULT_FROM_EMAIL = 'fastpick.xyz@gmail.com'
# SERVER_EMAIL = 'fastpick.xyz@gmail.com'
# EMAIL_HOST_USER = 'fastpick.xyz@gmail.com'
# EMAIL_HOST_PASSWORD = '742436sam'