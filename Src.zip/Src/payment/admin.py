from django.contrib import admin
from .models import RequestPayment
# Register your models here.
admin.site.register(RequestPayment)