# from django.contrib import admin
# from .models import Cart,Items
# # Register your models here.
# admin.site.register(Items)
# admin.site.register(Cart)