from django.contrib import admin
from .models import Complain,Contact
# Register your models here.
admin.site.register(Contact)
admin.site.register(Complain)