from django.contrib import admin

from tag.models import Tag

admin.site.register(Tag)